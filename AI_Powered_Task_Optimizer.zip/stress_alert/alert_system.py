def alert_hr(employee_id, mood):
    if mood == "stressed":
        print(f"Alert: Employee {employee_id} shows signs of stress.")
