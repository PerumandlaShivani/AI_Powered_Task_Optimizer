def detect_text_emotion(text):
    # Placeholder logic
    if "overwhelmed" in text.lower():
        return "stressed"
    return "neutral"
