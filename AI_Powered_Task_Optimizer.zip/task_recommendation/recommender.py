def recommend_task(mood):
    if mood == "stressed":
        return "Take a short break or do a low-priority task"
    return "Proceed with your regular high-priority task"
