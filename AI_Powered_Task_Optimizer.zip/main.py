from emotion_detection.text_emotion import detect_text_emotion
from task_recommendation.recommender import recommend_task

if __name__ == "__main__":
    sample_text = "I'm feeling really overwhelmed today."
    mood = detect_text_emotion(sample_text)
    print(f"Detected Mood: {mood}")
    task = recommend_task(mood)
    print(f"Recommended Task: {task}")
