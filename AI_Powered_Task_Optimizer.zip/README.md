# AI-Powered Task Optimizer

## Overview
This project uses AI to detect employee emotions from text, video, and audio to provide task recommendations and alert HR for stress management.

## Features
- Real-time emotion detection
- Mood-based task suggestions
- Stress alerts to HR
- Team mood analytics and historical mood tracking

## Requirements
See `requirements.txt` for dependencies.

## How to Run
```bash
pip install -r requirements.txt
python main.py
```